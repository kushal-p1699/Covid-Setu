package com.example.covidsetu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class OTPLoginActivity extends AppCompatActivity {

    private EditText phoneNumber;
    private Button btnGetOTP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otplogin);

        // initialize fields
        phoneNumber = (EditText) findViewById(R.id.edit_text_phone_number);
        btnGetOTP = (Button) findViewById(R.id.btn_get_otp);

        btnGetOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String _phoneNumber = phoneNumber.getText().toString().trim();
                if(!_phoneNumber.isEmpty()){
                    if(_phoneNumber.length() == 10){
                        Intent intent = new Intent(getApplicationContext(), VerifyOTP.class);
                        intent.putExtra("phone-number", _phoneNumber);
                        startActivity(intent);
                    }else{
                        Toast.makeText(OTPLoginActivity.this, "Please enter correct number", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(OTPLoginActivity.this, "Enter mobile number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}