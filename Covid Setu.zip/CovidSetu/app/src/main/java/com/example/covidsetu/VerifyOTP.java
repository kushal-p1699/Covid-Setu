package com.example.covidsetu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class VerifyOTP extends AppCompatActivity {

    private EditText otp1, otp2, otp3, otp4, otp5, otp6;
    private Button btnVerify;
    private TextView resendOtp, displayPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_otp);

        // initialize
        otp1 = (EditText) findViewById(R.id.edit_text_otp1);
        otp2 = (EditText) findViewById(R.id.edit_text_otp2);
        otp3 = (EditText) findViewById(R.id.edit_text_otp3);
        otp4 = (EditText) findViewById(R.id.edit_text_otp4);
        otp5 = (EditText) findViewById(R.id.edit_text_otp5);
        otp6 = (EditText) findViewById(R.id.edit_text_otp6);

        resendOtp = (TextView) findViewById(R.id.text_view_resend_otp);
        displayPhoneNumber = (TextView) findViewById(R.id.tv_phone_number);

        btnVerify = (Button) findViewById(R.id.btn_verify_otp);

        // display phone number
        displayPhoneNumber.setText(String.format(
                "+91-%s", getIntent().getStringExtra("phone-number")
        ));

        btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // validate otp input
                if(!otp1.getText().toString().trim().isEmpty()
                        && !otp2.getText().toString().trim().isEmpty()
                        && !otp3.getText().toString().trim().isEmpty()
                        && !otp4.getText().toString().trim().isEmpty()
                        && !otp5.getText().toString().trim().isEmpty()
                        && !otp6.getText().toString().trim().isEmpty()){
                    Toast.makeText(VerifyOTP.this, "otp verify", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(VerifyOTP.this, "Please enter all numbers", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // move to next input field
        MoveToNextOtpField();
    }

    private void MoveToNextOtpField() {
        otp1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    otp2.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        otp2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    otp3.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        otp3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    otp4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        otp4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    otp5.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        otp5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().trim().isEmpty()){
                    otp6.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}